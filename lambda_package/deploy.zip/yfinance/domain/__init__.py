# domain/__init__.py
from .sector import Sector
from .industry import Industry

__all__ = ['Sector', 'Industry']