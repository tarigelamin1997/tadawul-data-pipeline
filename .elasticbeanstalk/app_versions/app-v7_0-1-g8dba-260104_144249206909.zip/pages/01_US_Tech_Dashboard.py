import streamlit as st
import pandas as pd
import pandas_ta as ta
import plotly.graph_objects as go
from sqlalchemy import create_engine
import os

# --- 1. Page Config ---
st.set_page_config(page_title="US Tech Stocks", page_icon="📈", layout="wide")

st.title("📈 US Tech Stock Tracker (Pro)")
st.markdown("Live technical analysis of **TSLA, AAPL, NVDA** with 5-year history.")

# --- 2. Database Connection ---
# (Using st.secrets for security, or environment variables)
@st.cache_resource
def get_database_connection():
    # REPLACE these with your actual DB details or use st.secrets
    # Example: db_url = "postgresql://user:password@host:5432/dbname"
    
    # Ideally, fetch from Environment Variables (Elastic Beanstalk sets these)
    db_user = os.getenv("DB_USER", "postgres") 
    db_pass = os.getenv("DB_PASS", "YOUR_DB_PASSWORD_HERE") 
    db_host = os.getenv("DB_HOST", "tadawul-db.c8xyiyy40mmd.us-east-1.rds.amazonaws.com")
    db_name = os.getenv("DB_NAME", "tadawul")
    
    db_url = f"postgresql://{db_user}:{db_pass}@{db_host}:5432/{db_name}"
    return create_engine(db_url)

# --- 3. Fetch Data & Calculate Indicators ---
def load_data():
    engine = get_database_connection()
    query = "SELECT * FROM daily_prices ORDER BY date ASC"
    df = pd.read_sql(query, engine)
    return df

try:
    df = load_data()
    
    # Convert date to datetime if it isn't already
    df['date'] = pd.to_datetime(df['date'])

    # --- 4. Sidebar Controls ---
    st.sidebar.header("⚙️ Dashboard Controls")
    selected_symbol = st.sidebar.selectbox("Select Stock", df['symbol'].unique())

    # Filter data for selected stock
    stock_df = df[df['symbol'] == selected_symbol].copy()
    
    # --- 5. Technical Analysis (The "Senior Engineer" Part) ---
    # Calculate Simple Moving Averages (SMA)
    stock_df['SMA_50'] = ta.sma(stock_df['close'], length=50)
    stock_df['SMA_200'] = ta.sma(stock_df['close'], length=200)
    
    # Calculate RSI (Relative Strength Index)
    stock_df['RSI'] = ta.rsi(stock_df['close'], length=14)

    # --- 6. The Main Chart (Price + SMAs) ---
    st.subheader(f"{selected_symbol} Price Trends (Golden Cross Analysis)")
    
    fig = go.Figure()

    # Candlestick (Optional) or Line
    fig.add_trace(go.Scatter(
        x=stock_df['date'], y=stock_df['close'],
        mode='lines', name='Close Price',
        line=dict(color='white', width=2)
    ))

    # SMA 50 (Fast)
    fig.add_trace(go.Scatter(
        x=stock_df['date'], y=stock_df['SMA_50'],
        mode='lines', name='SMA 50 (Short Term)',
        line=dict(color='#00ffcc', width=1) # Cyan
    ))

    # SMA 200 (Slow)
    fig.add_trace(go.Scatter(
        x=stock_df['date'], y=stock_df['SMA_200'],
        mode='lines', name='SMA 200 (Long Term)',
        line=dict(color='#ff9900', width=1) # Orange
    ))

    fig.update_layout(
        template="plotly_dark",
        xaxis_title="Date",
        yaxis_title="Price (USD)",
        height=600,
        hovermode="x unified"
    )
    st.plotly_chart(fig, use_container_width=True)

    # --- 7. The RSI Chart (Momentum) ---
    st.subheader("Momentum (RSI)")
    st.markdown("RSI > 70 = Overbought (Sell Risk) | RSI < 30 = Oversold (Buy Opportunity)")
    
    rsi_fig = go.Figure()
    rsi_fig.add_trace(go.Scatter(
        x=stock_df['date'], y=stock_df['RSI'],
        mode='lines', name='RSI',
        line=dict(color='#bd00ff', width=2) # Purple
    ))
    
    # Add reference lines for 70 and 30
    rsi_fig.add_hline(y=70, line_dash="dash", line_color="red", annotation_text="Overbought")
    rsi_fig.add_hline(y=30, line_dash="dash", line_color="green", annotation_text="Oversold")
    
    rsi_fig.update_layout(
        template="plotly_dark",
        height=300,
        yaxis_range=[0, 100]
    )
    st.plotly_chart(rsi_fig, use_container_width=True)

    # --- 8. Recent Data Table ---
    st.subheader("📋 Latest 5 Days Data")
    st.dataframe(stock_df.tail(5).sort_values(by='date', ascending=False))

except Exception as e:
    st.error(f"Error loading dashboard: {e}")
    st.info("Check your database connection or ensure data exists in RDS.")